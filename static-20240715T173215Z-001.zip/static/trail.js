document.getElementById('file-upload').addEventListener('change', function() {
    var fileName = this.files[0] ? this.files[0].name : 'No file chosen';
    document.getElementById('file-name').textContent = fileName;
});

document.getElementById('upload-button').addEventListener('click', function() {
    const fileInput = document.getElementById('file-upload');
    if (fileInput.files.length === 0) {
        alert('Please choose a file first.');
        return;
    }

    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('file', file);

    fetch('/upload', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        // Handle the processed results
        const resultDiv = document.getElementById('result');
        if (data.file_type === 'image') {
            resultDiv.innerHTML = `<img src="${data.processed_file_url}" alt="Processed Image" style="max-width: 100%;">`;
        } else if (data.file_type === 'video') {
            resultDiv.innerHTML = `<video controls style="max-width: 100%;">
                                      <source src="${data.processed_file_url}" type="video/mp4">
                                      Your browser does not support the video tag.
                                   </video>`;
        }
    })
    .catch(error => {
        console.error('Error uploading and processing the file:', error);
    });
});
